--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.7
-- Dumped by pg_dump version 16.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "ProjectTEST";
--
-- Name: ProjectTEST; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "ProjectTEST" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Thai_Thailand.874';


ALTER DATABASE "ProjectTEST" OWNER TO postgres;

\connect "ProjectTEST"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: device; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.device (
    device_id integer NOT NULL,
    device_name character varying(100),
    device_description text,
    device_availability boolean,
    device_approve boolean
);


ALTER TABLE public.device OWNER TO postgres;

--
-- Name: device_device_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.device_device_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.device_device_id_seq OWNER TO postgres;

--
-- Name: device_device_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.device_device_id_seq OWNED BY public.device.device_id;


--
-- Name: loan_detail; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.loan_detail (
    loan_id integer NOT NULL,
    transaction_id integer NOT NULL,
    device_id integer NOT NULL,
    loan_date timestamp with time zone,
    location_to_loan character varying(100)
);


ALTER TABLE public.loan_detail OWNER TO postgres;

--
-- Name: loan_detail_device_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.loan_detail_device_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.loan_detail_device_id_seq OWNER TO postgres;

--
-- Name: loan_detail_device_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.loan_detail_device_id_seq OWNED BY public.loan_detail.device_id;


--
-- Name: loan_detail_loan_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.loan_detail_loan_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.loan_detail_loan_id_seq OWNER TO postgres;

--
-- Name: loan_detail_loan_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.loan_detail_loan_id_seq OWNED BY public.loan_detail.loan_id;


--
-- Name: loan_detail_transaction_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.loan_detail_transaction_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.loan_detail_transaction_id_seq OWNER TO postgres;

--
-- Name: loan_detail_transaction_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.loan_detail_transaction_id_seq OWNED BY public.loan_detail.transaction_id;


--
-- Name: return_detail; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.return_detail (
    return_id integer NOT NULL,
    transaction_id integer NOT NULL,
    device_id integer NOT NULL,
    return_date timestamp with time zone,
    location_to_return character varying(100)
);


ALTER TABLE public.return_detail OWNER TO postgres;

--
-- Name: return_detail_device_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.return_detail_device_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.return_detail_device_id_seq OWNER TO postgres;

--
-- Name: return_detail_device_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.return_detail_device_id_seq OWNED BY public.return_detail.device_id;


--
-- Name: return_detail_return_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.return_detail_return_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.return_detail_return_id_seq OWNER TO postgres;

--
-- Name: return_detail_return_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.return_detail_return_id_seq OWNED BY public.return_detail.return_id;


--
-- Name: return_detail_transaction_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.return_detail_transaction_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.return_detail_transaction_id_seq OWNER TO postgres;

--
-- Name: return_detail_transaction_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.return_detail_transaction_id_seq OWNED BY public.return_detail.transaction_id;


--
-- Name: room; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.room (
    room_id integer NOT NULL,
    device_id integer NOT NULL,
    room_availability boolean
);


ALTER TABLE public.room OWNER TO postgres;

--
-- Name: room_device_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.room_device_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.room_device_id_seq OWNER TO postgres;

--
-- Name: room_device_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.room_device_id_seq OWNED BY public.room.device_id;


--
-- Name: room_room_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.room_room_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.room_room_id_seq OWNER TO postgres;

--
-- Name: room_room_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.room_room_id_seq OWNED BY public.room.room_id;


--
-- Name: transaction; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.transaction (
    transaction_id integer NOT NULL,
    user_id integer NOT NULL,
    device_id integer NOT NULL,
    loan_id integer NOT NULL,
    return_id integer NOT NULL,
    loan_date_setting timestamp with time zone,
    return_date_setting timestamp with time zone,
    due_date_setting timestamp with time zone,
    transaction_history text,
    transaction_report text
);


ALTER TABLE public.transaction OWNER TO postgres;

--
-- Name: transaction_device_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.transaction_device_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.transaction_device_id_seq OWNER TO postgres;

--
-- Name: transaction_device_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.transaction_device_id_seq OWNED BY public.transaction.device_id;


--
-- Name: transaction_loan_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.transaction_loan_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.transaction_loan_id_seq OWNER TO postgres;

--
-- Name: transaction_loan_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.transaction_loan_id_seq OWNED BY public.transaction.loan_id;


--
-- Name: transaction_return_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.transaction_return_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.transaction_return_id_seq OWNER TO postgres;

--
-- Name: transaction_return_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.transaction_return_id_seq OWNED BY public.transaction.return_id;


--
-- Name: transaction_transaction_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.transaction_transaction_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.transaction_transaction_id_seq OWNER TO postgres;

--
-- Name: transaction_transaction_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.transaction_transaction_id_seq OWNED BY public.transaction.transaction_id;


--
-- Name: transaction_user_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.transaction_user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.transaction_user_id_seq OWNER TO postgres;

--
-- Name: transaction_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.transaction_user_id_seq OWNED BY public.transaction.user_id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    user_id integer NOT NULL,
    user_firstname character varying(100),
    user_lastname character varying(100),
    user_email character varying(100),
    user_password character varying(100),
    user_role character varying(100)
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_user_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_user_id_seq OWNER TO postgres;

--
-- Name: users_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_user_id_seq OWNED BY public.users.user_id;


--
-- Name: device device_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.device ALTER COLUMN device_id SET DEFAULT nextval('public.device_device_id_seq'::regclass);


--
-- Name: loan_detail loan_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.loan_detail ALTER COLUMN loan_id SET DEFAULT nextval('public.loan_detail_loan_id_seq'::regclass);


--
-- Name: loan_detail transaction_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.loan_detail ALTER COLUMN transaction_id SET DEFAULT nextval('public.loan_detail_transaction_id_seq'::regclass);


--
-- Name: loan_detail device_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.loan_detail ALTER COLUMN device_id SET DEFAULT nextval('public.loan_detail_device_id_seq'::regclass);


--
-- Name: return_detail return_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.return_detail ALTER COLUMN return_id SET DEFAULT nextval('public.return_detail_return_id_seq'::regclass);


--
-- Name: return_detail transaction_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.return_detail ALTER COLUMN transaction_id SET DEFAULT nextval('public.return_detail_transaction_id_seq'::regclass);


--
-- Name: return_detail device_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.return_detail ALTER COLUMN device_id SET DEFAULT nextval('public.return_detail_device_id_seq'::regclass);


--
-- Name: room room_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.room ALTER COLUMN room_id SET DEFAULT nextval('public.room_room_id_seq'::regclass);


--
-- Name: room device_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.room ALTER COLUMN device_id SET DEFAULT nextval('public.room_device_id_seq'::regclass);


--
-- Name: transaction transaction_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transaction ALTER COLUMN transaction_id SET DEFAULT nextval('public.transaction_transaction_id_seq'::regclass);


--
-- Name: transaction user_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transaction ALTER COLUMN user_id SET DEFAULT nextval('public.transaction_user_id_seq'::regclass);


--
-- Name: transaction device_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transaction ALTER COLUMN device_id SET DEFAULT nextval('public.transaction_device_id_seq'::regclass);


--
-- Name: transaction loan_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transaction ALTER COLUMN loan_id SET DEFAULT nextval('public.transaction_loan_id_seq'::regclass);


--
-- Name: transaction return_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transaction ALTER COLUMN return_id SET DEFAULT nextval('public.transaction_return_id_seq'::regclass);


--
-- Name: users user_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN user_id SET DEFAULT nextval('public.users_user_id_seq'::regclass);


--
-- Data for Name: device; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.device (device_id, device_name, device_description, device_availability, device_approve) FROM stdin;
\.
COPY public.device (device_id, device_name, device_description, device_availability, device_approve) FROM '$$PATH$$/3402.dat';

--
-- Data for Name: loan_detail; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.loan_detail (loan_id, transaction_id, device_id, loan_date, location_to_loan) FROM stdin;
\.
COPY public.loan_detail (loan_id, transaction_id, device_id, loan_date, location_to_loan) FROM '$$PATH$$/3394.dat';

--
-- Data for Name: return_detail; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.return_detail (return_id, transaction_id, device_id, return_date, location_to_return) FROM stdin;
\.
COPY public.return_detail (return_id, transaction_id, device_id, return_date, location_to_return) FROM '$$PATH$$/3400.dat';

--
-- Data for Name: room; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.room (room_id, device_id, room_availability) FROM stdin;
\.
COPY public.room (room_id, device_id, room_availability) FROM '$$PATH$$/3405.dat';

--
-- Data for Name: transaction; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.transaction (transaction_id, user_id, device_id, loan_id, return_id, loan_date_setting, return_date_setting, due_date_setting, transaction_history, transaction_report) FROM stdin;
\.
COPY public.transaction (transaction_id, user_id, device_id, loan_id, return_id, loan_date_setting, return_date_setting, due_date_setting, transaction_history, transaction_report) FROM '$$PATH$$/3390.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (user_id, user_firstname, user_lastname, user_email, user_password, user_role) FROM stdin;
\.
COPY public.users (user_id, user_firstname, user_lastname, user_email, user_password, user_role) FROM '$$PATH$$/3385.dat';

--
-- Name: device_device_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.device_device_id_seq', 1, false);


--
-- Name: loan_detail_device_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.loan_detail_device_id_seq', 1, false);


--
-- Name: loan_detail_loan_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.loan_detail_loan_id_seq', 1, false);


--
-- Name: loan_detail_transaction_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.loan_detail_transaction_id_seq', 1, false);


--
-- Name: return_detail_device_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.return_detail_device_id_seq', 1, false);


--
-- Name: return_detail_return_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.return_detail_return_id_seq', 1, false);


--
-- Name: return_detail_transaction_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.return_detail_transaction_id_seq', 1, false);


--
-- Name: room_device_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.room_device_id_seq', 1, false);


--
-- Name: room_room_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.room_room_id_seq', 1, false);


--
-- Name: transaction_device_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.transaction_device_id_seq', 1, false);


--
-- Name: transaction_loan_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.transaction_loan_id_seq', 1, false);


--
-- Name: transaction_return_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.transaction_return_id_seq', 1, false);


--
-- Name: transaction_transaction_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.transaction_transaction_id_seq', 1, false);


--
-- Name: transaction_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.transaction_user_id_seq', 1, false);


--
-- Name: users_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_user_id_seq', 8, true);


--
-- Name: device device_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.device
    ADD CONSTRAINT device_pkey PRIMARY KEY (device_id);


--
-- Name: loan_detail loan_detail_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.loan_detail
    ADD CONSTRAINT loan_detail_pkey PRIMARY KEY (loan_id);


--
-- Name: return_detail return_detail_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.return_detail
    ADD CONSTRAINT return_detail_pkey PRIMARY KEY (return_id);


--
-- Name: room room_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.room
    ADD CONSTRAINT room_pkey PRIMARY KEY (room_id);


--
-- Name: transaction transaction_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transaction
    ADD CONSTRAINT transaction_pkey PRIMARY KEY (transaction_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (user_id);


--
-- Name: loan_detail loan_device; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.loan_detail
    ADD CONSTRAINT loan_device FOREIGN KEY (device_id) REFERENCES public.device(device_id) NOT VALID;


--
-- Name: loan_detail loan_transaction; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.loan_detail
    ADD CONSTRAINT loan_transaction FOREIGN KEY (transaction_id) REFERENCES public.transaction(transaction_id) NOT VALID;


--
-- Name: return_detail return_device; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.return_detail
    ADD CONSTRAINT return_device FOREIGN KEY (device_id) REFERENCES public.device(device_id) NOT VALID;


--
-- Name: return_detail return_transaction; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.return_detail
    ADD CONSTRAINT return_transaction FOREIGN KEY (transaction_id) REFERENCES public.transaction(transaction_id) NOT VALID;


--
-- Name: room room_device; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.room
    ADD CONSTRAINT room_device FOREIGN KEY (device_id) REFERENCES public.device(device_id) NOT VALID;


--
-- Name: transaction transaction_device; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transaction
    ADD CONSTRAINT transaction_device FOREIGN KEY (device_id) REFERENCES public.device(device_id) NOT VALID;


--
-- Name: transaction transaction_loan; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transaction
    ADD CONSTRAINT transaction_loan FOREIGN KEY (loan_id) REFERENCES public.loan_detail(loan_id) NOT VALID;


--
-- Name: transaction transaction_return; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transaction
    ADD CONSTRAINT transaction_return FOREIGN KEY (return_id) REFERENCES public.return_detail(return_id) NOT VALID;


--
-- Name: transaction transaction_user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transaction
    ADD CONSTRAINT transaction_user FOREIGN KEY (user_id) REFERENCES public.users(user_id) NOT VALID;


--
-- PostgreSQL database dump complete
--

